import TestimonialCard1 from './TestimonialCard1';
import TestimonialCard2 from './TestimonialCard2';
import TestimonialCard3 from './TestimonialCard3';
import TestimonialCard4 from './TestimonialCard4';
import TestimonialCard5 from './TestimonialCard5';
import TestimonialCard6 from './TestimonialCard6';

export { TestimonialCard1, TestimonialCard2, TestimonialCard3, TestimonialCard4, TestimonialCard5, TestimonialCard6 };
