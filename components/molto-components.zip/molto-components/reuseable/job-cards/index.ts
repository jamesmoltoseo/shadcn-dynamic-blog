import JobPostCard1 from './JobPostCard1';
import JobPostCard2 from './JobPostCard2';

export { JobPostCard1, JobPostCard2 };
