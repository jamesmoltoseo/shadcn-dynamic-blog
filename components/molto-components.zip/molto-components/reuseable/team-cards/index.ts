// import TeamCard1 from './TeamCard1';
import TeamCard2 from './TeamCard2';
import TeamCard3 from './TeamCard3';

export { TeamCard2, TeamCard3 };
