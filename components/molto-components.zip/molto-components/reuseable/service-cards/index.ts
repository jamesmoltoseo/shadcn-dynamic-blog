import ServiceCard1 from './ServiceCard1';
import ServiceCard2 from './ServiceCard2';
import ServiceCard3 from './ServiceCard3';
import ServiceCard4 from './ServiceCard4';
import ServiceCard5 from './ServiceCard5';
import ServiceCard6 from './ServiceCard6';

export { ServiceCard1, ServiceCard2, ServiceCard3, ServiceCard4, ServiceCard5, ServiceCard6 };
