import PricingCard1 from './PricingCard1';
import PricingCard2 from './PricingCard2';

export { PricingCard1, PricingCard2 };
