import ProductCard from './ProductCard';
import ProductCard2 from './ProductCard2';

export { ProductCard, ProductCard2 };
