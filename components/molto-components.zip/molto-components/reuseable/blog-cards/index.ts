import BlogCard1 from './BlogCard1';
import BlogCard2 from './BlogCard2';
import BlogCard3 from './BlogCard3';
import BlogCard4 from './BlogCard4';
import BlogCard5 from './BlogCard5';

export { BlogCard1, BlogCard2, BlogCard3, BlogCard4, BlogCard5 };
