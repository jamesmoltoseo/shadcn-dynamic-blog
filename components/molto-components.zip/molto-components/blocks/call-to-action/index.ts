import CTA1 from './CTA1';
import CTA2 from './CTA2';
import CTA3 from './CTA3';
import CTA4 from './CTA4';
import CTA5 from './CTA5';
import CTA6 from './CTA6';
import CTA7 from './CTA7';
import CTA8 from './CTA8';
import CTA9 from './CTA9';
import CTA10 from './CTA10';

export { CTA1, CTA2, CTA3, CTA4, CTA5, CTA6, CTA7, CTA8, CTA9, CTA10 };
