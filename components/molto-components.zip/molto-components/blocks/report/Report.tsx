import { FC } from 'react';
const Report: FC = () => {
  return (
    <>
      {/* <p>Get your free online consultation & report</p> */}
      
        <a
          href="#"
          data-bs-toggle="modal"
          data-bs-target="#performance-audit"
          className="btn btn-sm btn-fuchsia rounded-pill"
        >
          Free Consultation
        </a>
    
    </>
  );
};

export default Report;
