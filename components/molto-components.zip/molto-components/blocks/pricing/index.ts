import Pricing1 from './Pricing1';
import Pricing2 from './Pricing2';
import Pricing3 from './Pricing3';
import Pricing4 from './Pricing4';
import Pricing5 from './Pricing5';
import Pricing6 from './Pricing6';
import Pricing7 from './Pricing7';
import Pricing8 from './Pricing8';
import Pricing9 from './Pricing9';
import Pricing10 from './Pricing10';

export { Pricing1, Pricing2, Pricing3, Pricing4, Pricing5, Pricing6, Pricing7, Pricing8, Pricing9, Pricing10 };
