import Team1 from './Team1';
import Team2 from './Team2';
import Team3 from './Team3';
import Team4 from './Team4';
import Team5 from './Team5';
import Team6 from './Team6';
import Team7 from './Team7';
import Team8 from './Team8';

export { Team1, Team2, Team3, Team4, Team5, Team6, Team7, Team8 };
