import Facts1 from './Facts1';
import Facts2 from './Facts2';
import Facts3 from './Facts3';
import Facts4 from './Facts4';
import Facts5 from './Facts5';
import Facts6 from './Facts6';
import Facts7 from './Facts7';
import Facts8 from './Facts8';
import Facts9 from './Facts9';
import Facts10 from './Facts10';
import Facts11 from './Facts11';
import Facts12 from './Facts12';
import Facts13 from './Facts13';
import Facts14 from './Facts14';
import Facts15 from './Facts15';
import Facts16 from './Facts16';
import Facts17 from './Facts17';

export {
  Facts1,
  Facts2,
  Facts3,
  Facts4,
  Facts5,
  Facts6,
  Facts7,
  Facts8,
  Facts9,
  Facts10,
  Facts11,
  Facts12,
  Facts13,
  Facts14,
  Facts15,
  Facts16,
  Facts17
};
