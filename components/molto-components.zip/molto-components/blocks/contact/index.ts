import Contact1 from './Contact1';
import Contact2 from './Contact2';
import Contact3 from './Contact3';
import Contact4 from './Contact4';
import Contact5 from './Contact5';
import Contact6 from './Contact6';
import Contact7 from './Contact7';
import Contact8 from './Contact8';
import Contact9 from './Contact9';
import Contact10 from './Contact10';
import Contact11 from './Contact11';
import Contact12 from './Contact12';
import Contact13 from './Contact13';

export {
  Contact1,
  Contact2,
  Contact3,
  Contact4,
  Contact5,
  Contact6,
  Contact7,
  Contact8,
  Contact9,
  Contact10,
  Contact11,
  Contact12,
  Contact13
};
